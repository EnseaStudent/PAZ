# emptyBaseProject2023

Projet à vocation pédagogique pour les étudiants de l'ENSEA en langage C pour microcontrôleur.

Ce projet initialise les principaux périphérique de la carte puis éxécute en boucle la fonction "loop" du fichier "studentWork.c". 
 
