/*
 * studentWork.c
 *
 *  Created on: Jun 21, 2023
 *      Author: antotauv
 */

#include <stm32l4xx_hal.h>
#include "ensea.h"
extern UART_HandleTypeDef huart2;
void setup(void){
    // insert the setup here, it will be run once.
}

void loop(void){
    // This code will run indefinitly.
   
}

