/*
 * ensea.h
 *
 *  Created on: Jun 21, 2023
 *      Author: antotauv
 */

#ifndef INC_ENSEA_H_
#define INC_ENSEA_H_

#include <stdio.h>

void setup(void);
void loop(void);


#endif /* INC_ENSEA_H_ */
