/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32l4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32l4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */



/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* affectation des valeurs conventionnelles*
 **
 */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern ADC_HandleTypeDef hadc1;
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32L4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32l4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles ADC1 and ADC2 interrupts.
  */
void ADC1_2_IRQHandler(void)
{
  /* USER CODE BEGIN ADC1_2_IRQn 0 */


#include <stdio.h>
#include <math.h>

#define PI 3.14159265358979323846

typedef struct {
    float a1, a2;
    float b0, b1, b2;
    float z1, z2;
} Biquad;

typedef struct {
    Biquad sections[2]; // Deux sections biquad pour un filtre d'ordre 4
} LowPassFilter4thOrder;

// Initialisation des coefficients pour une section biquad
void initBiquad(Biquad* biquad, float sample_rate, float cutoff_frequency) {
    float w0 = 2 * PI * cutoff_frequency / sample_rate;
    float cos_w0 = cos(w0);
    float sin_w0 = sin(w0);
    float alpha = sin_w0 / (2 * sqrt(2)); // Pour un filtre Butterworth de second ordre

    float b0 = (1 - cos_w0) / 2;
    float b1 = 1 - cos_w0;
    float b2 = (1 - cos_w0) / 2;
    float a0 = 1 + alpha;
    float a1 = -2 * cos_w0;
    float a2 = 1 - alpha;

    // Normalisation des coefficients
    biquad->b0 = b0 / a0;
    biquad->b1 = b1 / a0;
    biquad->b2 = b2 / a0;
    biquad->a1 = a1 / a0;
    biquad->a2 = a2 / a0;

    biquad->z1 = 0;
    biquad->z2 = 0;
}

// Filtrage d'un échantillon par une section biquad
float processBiquad(Biquad* biquad, float input) {
    float output = biquad->b0 * input + biquad->b1 * biquad->z1 + biquad->b2 * biquad->z2
                   - biquad->a1 * biquad->z1 - biquad->a2 * biquad->z2;
    biquad->z2 = biquad->z1;
    biquad->z1 = input;
    return output;
}

// Initialisation du filtre passe-bas d'ordre 4
void initLowPassFilter4thOrder(LowPassFilter4thOrder* filter, float sample_rate, float cutoff_frequency) {
    for (int i = 0; i < 2; ++i) {
        initBiquad(&filter->sections[i], sample_rate, cutoff_frequency);
    }
}

// Filtrage d'un échantillon par le filtre passe-bas d'ordre 4
float processLowPassFilter4thOrder(LowPassFilter4thOrder* filter, float input) {
    float output = input;
    for (int i = 0; i < 2; ++i) {
        output = processBiquad(&filter->sections[i], output);
    }
    return output;
}
















	static int L = 2300;
	static int index = 0;
	static int resultArray[2300]={0};
	int result=ADC1->DR;
	resultArray[index]= result ;
	index +=1;








	int is_pulse = 0 ;// test de pulse
	int is_zombie = 0 ; // test zombie
	int card_pulse = 0; // Compteur pulse
	float bpm;
	float filteredARRAY[2300]={0};






	if (index==L){
		index =0;

	/*     CALCUL DE LA MOYENNE     */

		int mean = 0;
		for (int i=0;i<L-1;i++)  {mean+=resultArray[i]; }
		mean = mean/L;
		int stdDev = 0;

	/*     CALCUL DE L'ECART TYPE     */

		for (int i=0;i<L-1;i++)   {stdDev += (resultArray[i] - mean)*(resultArray[i] - mean) ; printf("élément [%d] \t %d \n\r",i,resultArray[i]);}
		stdDev = sqrt (stdDev/L);

	/*     AFFICHAGE MOYENNE ET ECART TYPE     */

		printf("Running analysis : mean = %d \t stdDeviation = %d\r\n",mean,stdDev);





		float sample_rate = 1000.0; // Fréquence d'échantillonnage en Hz
		float cutoff_frequency = 10.0; // Fréquence de coupure en Hz
		LowPassFilter4thOrder filter;
		initLowPassFilter4thOrder(&filter, sample_rate, cutoff_frequency);


				//int num_samples = sizeof(resultArray) / sizeof(resultArray[0]);

		printf("Signal filtré :\n");
		for (int i = 0; i < L-1; ++i)
		{
			float filtered_sample = processLowPassFilter4thOrder(&filter, resultArray[i]);
			filteredARRAY[i]= filtered_sample;
		}




		int indmax1;
		int max1 = 0 ;
		int indmax2;
		int max2 = 0 ;

		for (int i=0;i<(L-1)/2;i++){

			if (filteredARRAY[i]>max1)
			{
				max1 = filteredARRAY[i];
				indmax1 = i;
			}

			if (filteredARRAY[(L-1)/2+i]>max2)
			{
				max2 = filteredARRAY[(L-1)/2+i];
				indmax2 = (L-1)/2+i;
			}
		}

		printf("MAX 1 : \t %d en :\t %d \n\r",max1, indmax1);
		printf("MAX 2 : \t %d en :\t %d \n\r",max2, indmax2);







		float bpm = 60000/(indmax2-indmax1);
	if (bpm < 40 ){is_zombie = 1;};

	switch (is_zombie)
		{

	case 1 :
		printf("YOU ARE A ZOMBIE \n\r");
		break;

	case 0 :
		printf ("Pulsation : \t %f \n\r", bpm);
		break;
		}


	}



  /* USER CODE END ADC1_2_IRQn 0 */
  HAL_ADC_IRQHandler(&hadc1);
  /* USER CODE BEGIN ADC1_2_IRQn 1 */

  /* USER CODE END ADC1_2_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
